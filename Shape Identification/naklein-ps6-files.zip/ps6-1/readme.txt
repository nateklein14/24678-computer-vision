OS: Windows 11
IDE: VSCode
Hours Spent: 1