OS: Windows 11
IDE: VSCode
Hours spent: 5 hours