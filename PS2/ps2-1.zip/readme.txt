OS: Windows 11
IDE: VSCode
Time Spent: 4 hours